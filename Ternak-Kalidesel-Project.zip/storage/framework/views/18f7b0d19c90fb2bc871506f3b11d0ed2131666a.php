<?php $__env->startSection('content'); ?>

        <div >
                <h1>Instal Laravel</h1>
        </div>

        <div class="list-group">
            <a href="https://drive.google.com/file/d/1vqBkRowFd6p6KQ5kNBBIVsaam4Hd2EJA/view?usp=sharing" class="list-group-item list-group-item-action active">
                Langkah-langkah yang membuat project laravel.
            </a>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Belajar Web 2 (Laravel)\UTS_WEB2_2020\resources\views/instal.blade.php ENDPATH**/ ?>