<?php $__env->startSection('content'); ?>
        <div >
                <h1>UTS WEB 2 – Dhiaulhaq Aryaputra Falah Amurya</h1>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Belajar Web 2 (Laravel)\Belajar Laravel Versi 6\resources\views/home.blade.php ENDPATH**/ ?>