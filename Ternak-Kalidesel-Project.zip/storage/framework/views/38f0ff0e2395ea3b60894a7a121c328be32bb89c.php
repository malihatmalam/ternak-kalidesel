<?php $__env->startSection('content'); ?>
<div class="container">
        <?php if(Session::has('pesan')): ?>
                <div class="alert alert-success"><?php echo e(Session::get('pesan')); ?></div>
        <?php endif; ?>

        <div class="container" >
                <h1>Buku</h1>

        </div>
        <div class="container">
                <p> 
                        <a href="<?php echo e(route('buku.create')); ?>" class="btn btn-primary">
                                Tambah Buku
                        </a>
                </p>

                        <div class="container">
                                <form action="<?php echo e(route('buku.search')); ?>" method="get"><?php echo csrf_field(); ?>
                                        <input type="text" name="kata" class="form-control" placeholder="Cari..." 
                                        style="width:30%; display:inline; margin-top:10px; margin-bottom:10px; float:right;">
                                </form>
                        </div>
                
                <table class="table table-striped">
                        <thead>
                                <tr>
                                        <th> No </th>
                                        <th> Judul </th>
                                        <th> Penulis </th>
                                        <th> Harga </th>
                                        <th> Tanggal Terbit </th>
                                        <th> Foto </th>                                       
                                </tr>
                        </thead>
                        <tbody>
                                <?php $__currentLoopData = $data_book; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                        <td><?php echo e(++$no); ?></td>
                                        <td><?php echo e($buku->judul); ?></td>
                                        <td><?php echo e($buku->penulis); ?></td>
                                        <td><?php echo e("Rp ".number_format($buku->harga,2,',','.')); ?></td>
                                        <td>
                                                <img src="<?php echo e($buku->foto != null ? 
                                                                asset('images/'.$buku->foto) : 
                                                                asset('image-not-found.jpg')); ?>" 
                                                                        style="width: 100px">
                                        </td>
                                        <td><?php echo e($buku->tgl_terbit->format('d/m/Y')); ?></td>
                                        <td>
                                                <form action="<?php echo e(route('buku.deleted', $buku -> id )); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                                <a href="<?php echo e(route('buku.edit', $buku -> id)); ?>" class="btn btn-warning">
                                                                        Update
                                                                </a>

                                                                <button type="submit" class="btn btn-danger" onClick="return confirm('Apakah anda yakin ?') " >
                                                                        Delete
                                                                </button>
                                                </form>
                                                
                                        </td>                                       
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                </table>
                
                <div>
                        <div class="kiri"><strong>Jumlah Buku: <?php echo e($jumlah_buku); ?></strong></div>
                        <div class="kanan"><?php echo e($data_book->links()); ?></div>
                </div>
        </div>
</div>
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Belajar Web 2 (Laravel)\Belajar Laravel Versi 6\resources\views/book/index_book.blade.php ENDPATH**/ ?>