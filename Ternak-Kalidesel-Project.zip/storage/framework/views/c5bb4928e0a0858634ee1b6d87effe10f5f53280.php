<?php $__env->startSection('content'); ?>
<div class="container">
        <div class="container" >
                <h1>Update Buku</h1>
                <?php if(count($errors)>0): ?>
                <ul class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
        <?php endif; ?>
        </div>
        <div class="container">
                <form action="<?php echo e(route('buku.update', $buku -> id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                    <table >
                    <div class="container"> 
                        <div class="form-group row">
                            <label for="judul_buku" class="col-sm-3 col-form-label" > Judul </label>
                            <div class="col-sm-9">
                                <input type="text" id="judul" name="judul" class="form-control" value="<?php echo e($buku -> judul); ?>">

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="penuliss_buku" class="col-sm-3 col-form-label" > Penulis </label>
                            <div class="col-sm-9">
                                <input type="text" id="penulis" name="penulis" class="form-control" value="<?php echo e($buku -> penulis); ?>">
                                
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="harga_buku" class="col-sm-3 col-form-label" > Harga </label>
                            <div class="col-sm-9">
                                <input type="text" id="harga" name="harga" class="form-control" value="<?php echo e($buku -> harga); ?>">
                                
                            </div>
                        </div>
                        </div>
                        <div class="form-group row">
                            <label for="harga_buku" class="col-sm-3 col-form-label" > Gambar </label>
                            <div>
                                <img src="<?php echo e($buku->foto != null ? asset('images/'.$buku->foto) : asset('image-not-found.jpg')); ?>" style="width: 100px">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="harga_buku" class="col-sm-3 col-form-label" > Upload Foto </label>
                            <div class="col-sm-9">
                                <input type="file" class="form-control" name="foto">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="tgl_terbit_buku" class="col-sm-3 col-form-label" > Tanggal Terbit </label>
                            <div class="col-sm-9">
                                <input type="text" id="tgl_terbit" name="tgl_terbit" class="form-control" value="<?php echo e($buku -> tgl_terbit); ?>">
                                
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-9">
                                    <button type="submit" class="btn btn-primary"> Simpan </button>
                                    <a href="/book" class="btn btn-warning" > Kembali </a>
                            </div>
                        </div>
                    </div>
                </table>
            </form>
                
        </div>
</div>
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Belajar Web 2 (Laravel)\Belajar Laravel Versi 6\resources\views/book/update_book.blade.php ENDPATH**/ ?>