<?php $__env->startSection('content'); ?>
<!-- INPUTS -->
<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
                    <?php if(Session::has('pesan')): ?>
                        <div class="alert alert-success"><?php echo e(Session::get('pesan')); ?></div>
                    <?php endif; ?>
                    <h2 class="page-title">Daftar Hewan Ternak <b> (Semuanya) </b></h2>
                    <div class="row">

                            <div class="panel panel-headline">
                            <div class="panel-heading">
                                <h3 class="panel-title">Ringkasan Informasi Mengenai Stok Ternak</h3>
                                <p class="panel-subtitle">Hari ini</p>
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="metric">
                                            <span class="icon"><i class="fa fa-bar-chart"></i></span>
                                            <p>
                                                <span class="number"><?php echo e($jumlah_stock); ?> Ekor</span>
                                                <span class="title">Stok Hewan</span>
                                            </p>
                                            <br>
                                            <br>
                                            <div>
                                                <h3 class="panel-title">Tambah Data Hewan Ternak</h3>
                                                <br>
                                                <form action="<?php echo e(route('livestock.add' )); ?>" method="GET">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn btn-primary">Tambah</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="metric">
                                            <span class="icon"><i class="fa fa-bar-chart"></i></span>
                                            <p>
                                                <span class="number"><?php echo e($jumlah_dibeli); ?> Ekor</span>
                                                <span class="title">Hewan Yang Sudah Dibeli</span>
                                            </p>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="metric">
                                            <span class="icon"><i class="fa fa-bar-chart"></i></span>
                                            <p>
                                                <span class="number"><?php echo e($jumlah_mati); ?> Ekor</span>
                                                <span class="title">Hewan Yang Sudah Mati</span>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <h3>Pencarian</h3>
                                    <form action="<?php echo e(route('livestock.search')); ?>" method="get">
                                        <?php echo csrf_field(); ?>
                                            <input type="text" name="kata" class="form-control" placeholder="Cari..." 
                                            style="width:30%; display:inline; margin-top:10px; margin-bottom:10px; float:left;">
                                    </form>
                            </div>
                        </div>
                    </div>
                    


                    <div class="panel">
                        <div class="panel-body">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th> No </th>
                                        <th> jenis </th>
                                        <th> Kode Hewan</th>
                                        <th> Kode Kandang </th>
                                        <th> Tipe </th>
                                        <th> Jenis Kelamin </th>
                                        <th> Warna </th>
                                        <th> Tanggal Lahir </th>
                                        <th> Berat </th>
                                        <th> Status </th>
                                        <th> Aksi </th>
                                         <!-- <th> Deskripsi </th> -->
                                        <!-- <th> Foto </th> -->
                                    </tr>
                                </thead>
                                <tbody>
                                        <?php $__currentLoopData = $livestock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(++$no); ?></td>
                                            <td>
                                                <?php if($animal->jenis == 'cow'): ?>
                                                    <img src="<?php echo e(asset('admin/assets/images/Sapi.jpg')); ?>" style="width: 100px">
                                                <?php endif; ?>
                                                <?php if($animal->jenis == 'goat'): ?>
                                                    <img src="<?php echo e(asset('admin/assets/images/Kambing.jpg')); ?>" style="width: 100px">
                                                <?php endif; ?>
                                                <?php if($animal->jenis == 'sheep'): ?>
                                                    <img src="<?php echo e(asset('admin/assets/images/Domba.jpg')); ?>" style="width: 100px">
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($animal->kode); ?></td>
                                            <td><?php echo e($animal->kode_kandang); ?></td>
                                            <td><?php echo e($animal->type); ?></td>
                                            <td>
                                                <?php if($animal->jenis_kelamin == 'male'): ?>
                                                    <span>Jantan</span></td>
                                                <?php endif; ?>
                                                <?php if($animal->jenis_kelamin == 'female'): ?>
                                                    <span>Betina</span></td>
                                                <?php endif; ?>                                            </td>
                                            <td><?php echo e($animal->warna); ?></td>
                                            <td><?php echo e($animal->tgl_lahir->format('d/m/Y')); ?></td>
                                            <!-- <td><?php echo e($animal->description); ?></td> -->
                                            <td><?php echo e($animal->berat); ?></td>
                                            <td>
                                                <?php if($animal->status == 'Sudah dibeli'): ?>
                                                    <span class="label label-success"><?php echo e($animal->status); ?></span></td>
                                                <?php endif; ?>
                                                <?php if($animal->status == 'Belum dibeli'): ?>
                                                    <span class="label label-warning"><?php echo e($animal->status); ?></span></td>
                                                <?php endif; ?>
                                                <?php if($animal->status == 'Mati'): ?>
                                                    <span class="label label-danger"><?php echo e($animal->status); ?></span></td>
                                                <?php endif; ?>
                                            <td>
                                                    <form action="<?php echo e(route('livestock.mati', $animal-> id )); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <a href="<?php echo e(route('livestock.detail', $animal -> id)); ?>" class="btn btn-primary">
                                                                Detail
                                                            </a>
                                                            <!-- <a href="<?php echo e(route('livestock.edit', $animal -> id)); ?>" class="btn btn-warning">
                                                                Update
                                                            </a> -->
                                                            <button type="submit" class="btn btn-danger" onClick="return confirm('Apakah anda yakin ?') " >
                                                                Mati
                                                            </button>
                                                    </form>
                                            </td>                                       
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <div>
                                    <div class="kiri"><strong>Jumlah Hewan : <?php echo e($jumlah_hewan); ?></strong></div>
                                    <div class="kanan"><?php echo e($livestock->links()); ?></div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
   
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout_master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Belajar Web 2 (Laravel)\Proyek Praktikum Pemograman Web 2\Ternak Pak Abdulah Project\resources\views/manajemen/livestock.blade.php ENDPATH**/ ?>