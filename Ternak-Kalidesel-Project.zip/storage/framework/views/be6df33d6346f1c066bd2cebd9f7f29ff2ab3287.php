<?php $__env->startSection('content'); ?>
        <div >
                <h1>About Me</h1>
        </div>

        <div class="card" style="width: 18rem;">
        <img src="<?php echo e(('img/foto.jpg')); ?>" class="card-img-top" alt="...">
        <div class="card-body">
            <h5 class="card-title">Dhiaulhaq Aryaputra Falah Amurya</h5>
            <h6 class="card-subtitle mb-2 text-muted">NIM : 19/441221/SV/16573</h6>
            <p class="card-text">Saya lahir di Tegal tanggal 26 September 2020</p>
            <p class="card-text">Saya tinggal di Kota Tegal</p>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Belajar Web 2 (Laravel)\UTS_WEB2_2020\resources\views/about.blade.php ENDPATH**/ ?>