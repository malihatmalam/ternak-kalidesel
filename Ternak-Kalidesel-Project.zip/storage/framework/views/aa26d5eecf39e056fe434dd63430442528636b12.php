<?php $__env->startSection('content'); ?>
<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<!-- OVERVIEW -->
					<div class="panel panel-headline">
						<div class="panel-heading">
							<h3 class="panel-title">Ringkasan Informasi</h3>
							<p class="panel-subtitle">Hari ini</p>
						</div>
						<div class="panel-body">
							<div class="row">
								<div class="col-md-3">
									<div class="metric">
										<span class="icon"><i class="fa fa-bar-chart"></i></span>
										<p>
											<span class="number"><?php echo e($jumlah_menunggu); ?></span>
											<span class="title">Pesanan Menunggu</span>
										</p>
									</div>
								</div>
								<div class="col-md-3">
									<div class="metric">
										<span class="icon"><i class="fa fa-bar-chart"></i></span>
										<p>
											<span class="number"><?php echo e($jumlah_kirim); ?></span>
											<span class="title">Pesanan Dikirim</span>
										</p>
									</div>
								</div>
								<div class="col-md-3">
									<div class="metric">
										<span class="icon"><i class="fa fa-bar-chart"></i></span>
										<p>
											<span class="number"><?php echo e($jumlah_sukses); ?></span>
											<span class="title">Pesanan Sukses</span>
										</p>
									</div>
								</div>
								<div class="col-md-3">
									<div class="metric">
										<span class="icon"><i class="fa fa-bar-chart"></i></span>
										<p>
											<span class="number"><?php echo e($jumlah_batal); ?></span>
											<span class="title">Pesanan Gagal</span>
										</p>
									</div>
								</div>
								<div class="col-md-3">
									<div class="metric">
										<span class="icon"><i class="fa fa-bar-chart"></i></span>
										<p>
											<span class="number"><?php echo e($jumlah_stock); ?> Ekor</span>
											<span class="title">Stok Hewan</span>
										</p>
										<br>
										<br>
										<div>
											<h3 class="panel-title">Tambah Data Hewan Ternak</h3>
											<br>
											<form action="<?php echo e(route('livestock.add' )); ?>" method="GET">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn btn-primary">Tambah</button>
                                            </form>
										</div>
									</div>
								</div>
								<div class="col-md-3">
									<div class="metric">
										<span class="icon"><i class="fa fa-bar-chart"></i></span>
										<p>
											<span class="number"><?php echo e($jumlah_mati); ?> Ekor</span>
											<span class="title">Hewan yang Mati</span>
										</p>
									</div>
								</div>
							</div>
						</div>
					
					</div>
					<!-- RECENT PURCHASES -->
					<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">Pesanan Menunggu</h3>
									<div class="right">
										<button type="button" class="btn-toggle-collapse"><i class="lnr lnr-chevron-up"></i></button>
										<button type="button" class="btn-remove"><i class="lnr lnr-cross"></i></button>
									</div>
								</div>
								<div class="panel-body no-padding">
								<table class="table table-hover">
									<thead>
										<tr>
											<th> No </th>
											<th> Nomor Pesanan </th>
											<th> Nama Pemesan</th>
											<th> Nomor Telepon </th>
											<th> Tanggal Pembayaran </th>
											<th> Tanggal Antar </th>
											<th> Status </th>
											<th> Aksi </th>
											<!-- <th> Deskripsi </th> -->
											<!-- <th> Foto </th> -->
										</tr>
									</thead>
									<tbody>
											<?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $od): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr>
												<td><?php echo e(++$no); ?></td>
												<td><?php echo e($od->kode); ?></td>
												<td><?php echo e($od->name); ?></td>
												<td><?php echo e($od->telephone); ?></td>
												<td><?php echo e($od->tgl_beli->format('d/m/Y')); ?></td>
												<td><?php echo e($od->tgl_antar->format('d/m/Y')); ?></td>
												<td>
													<?php if($od->status == 'Sukses'): ?>
														<span class="label label-success"><?php echo e($od->status); ?></span></td>
													<?php endif; ?>
													<?php if($od->status == 'Menunggu'): ?>
														<span class="label label-warning"><?php echo e($od->status); ?></span></td>
													<?php endif; ?>
													<?php if($od->status == 'Tolak'): ?>
														<span class="label label-danger"><?php echo e($od->status); ?></span></td>
													<?php endif; ?>
													<?php if($od->status == 'Kirim'): ?>
														<span class="label label-info"><?php echo e($od->status); ?></span></td>
													<?php endif; ?>
												<td>
														<a href="<?php echo e(route('order.detail', $od -> id)); ?>" class="btn btn-info">
															Detail
														</a>
												</td>                                       
											</tr>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tbody>
								</table>
								<div>
										<div class="kiri"><strong>Jumlah Order  : <?php echo e($jumlah_menunggu); ?></strong></div>
										<div class="kanan"><?php echo e($order->links()); ?></div>
								</div>
							</div>
							<!-- END RECENT PURCHASES -->
                </div>
            </div>
</div>
					<!-- END OVERVIEW -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout_master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\PROJECK\Ternak Kalidesel Project\resources\views/manajemen/manajemen_dashboard.blade.php ENDPATH**/ ?>