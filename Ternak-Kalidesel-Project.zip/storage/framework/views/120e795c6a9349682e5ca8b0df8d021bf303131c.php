<?php $__env->startSection('content'); ?>
<!-- INPUTS -->
<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
                    <?php if(Session::has('pesan')): ?>
                        <div class="alert alert-success"><?php echo e(Session::get('pesan')); ?></div>
                    <?php endif; ?>
                    <h2 class="page-title">Daftar Pesanan <b> (Semuanya) </b></h2>
                    <div class="row">

                            <div class="panel panel-headline">
                            <div class="panel-heading">
                                <h3 class="panel-title">Ringkasan Informasi Mengenai Pesanan Hewan Ternak</h3>
                                <p class="panel-subtitle">Hari ini</p>
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="metric">
                                            <span class="icon"><i class="fa fa-bar-chart"></i></span>
                                            <p>
                                                <span class="number"><?php echo e($jumlah_order); ?></span>
                                                <span class="title">Jumlah Pesanan</span>
                                            </p>
                                            <br>
                                            <br>
                                            <div>
                                                <h3 class="panel-title">Tambah Data Pesanan</h3>
                                                <br>
                                                <form action="<?php echo e(route('order.add' )); ?>" method="GET">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn btn-primary">Tambah</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="metric">
                                            <span class="icon"><i class="fa fa-bar-chart"></i></span>
                                            <p>
                                                <span class="number"><?php echo e($jumlah_menunggu); ?></span>
                                                <span class="title">Pesanan Yang Belom Diproses</span>
                                            </p>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="metric">
                                            <span class="icon"><i class="fa fa-bar-chart"></i></span>
                                            <p>
                                                <span class="number"><?php echo e($jumlah_kirim); ?></span>
                                                <span class="title">Pesanan Yang Sedang Dikirim</span>
                                            </p>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="metric">
                                            <span class="icon"><i class="fa fa-bar-chart"></i></span>
                                            <p>
                                                <span class="number"><?php echo e($jumlah_sukses); ?></span>
                                                <span class="title">Pesanan Yang Sukses</span>
                                            </p>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="metric">
                                            <span class="icon"><i class="fa fa-bar-chart"></i></span>
                                            <p>
                                                <span class="number"><?php echo e($jumlah_batal); ?></span>
                                                <span class="title">Pesanan Yang Dibatalkan</span>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <h3>Pencarian</h3>
                                    <!-- <form action="<?php echo e(route('order.search')); ?>" method="get">
                                        <?php echo csrf_field(); ?>
                                            <input type="text" name="kata" class="form-control" placeholder="Cari..." 
                                            style="width:30%; display:inline; margin-top:10px; margin-bottom:10px; float:left;">
                                    </form> -->
                            </div>
                        </div>
                    </div>
                    


                    <div class="panel">
                        <div class="panel-body">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th> No </th>
                                        <th> Nomor Pesanan </th>
                                        <th> Nama Pemesan</th>
                                        <th> Nomor Telepon </th>
                                        <th> Tanggal Pembayaran </th>
                                        <th> Tanggal Antar </th>
                                        <th> Status </th>
                                        <th> Aksi </th>
                                         <!-- <th> Deskripsi </th> -->
                                        <!-- <th> Foto </th> -->
                                    </tr>
                                </thead>
                                <tbody>
                                        <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $od): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(++$no); ?></td>
                                            <td><?php echo e($od->kode); ?></td>
                                            <td><?php echo e($od->name); ?></td>
                                            <td><?php echo e($od->telephone); ?></td>
                                            <td><?php echo e($od->tgl_beli->format('d/m/Y')); ?></td>
                                            <td><?php echo e($od->tgl_antar->format('d/m/Y')); ?></td>
                                            <td>
                                                <?php if($od->status == 'Sukses'): ?>
                                                    <span class="label label-success"><?php echo e($od->status); ?></span></td>
                                                <?php endif; ?>
                                                <?php if($od->status == 'Menunggu'): ?>
                                                    <span class="label label-warning"><?php echo e($od->status); ?></span></td>
                                                <?php endif; ?>
                                                <?php if($od->status == 'Tolak'): ?>
                                                    <span class="label label-danger"><?php echo e($od->status); ?></span></td>
                                                <?php endif; ?>
                                                <?php if($od->status == 'Kirim'): ?>
                                                    <span class="label label-info"><?php echo e($od->status); ?></span></td>
                                                <?php endif; ?>
                                            <td>
                                                    <a href="<?php echo e(route('order.detail', $od -> id)); ?>" class="btn btn-info">
                                                        Detail
                                                    </a>
                                            </td>                                       
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <div>
                                    <div class="kiri"><strong>Jumlah Order  : <?php echo e($jumlah_order); ?></strong></div>
                                    <div class="kanan"><?php echo e($order->links()); ?></div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
   
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout_master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Belajar Web 2 (Laravel)\Proyek Praktikum Pemograman Web 2\Ternak Pak Abdulah Project\resources\views/manajemen/order/order_index.blade.php ENDPATH**/ ?>