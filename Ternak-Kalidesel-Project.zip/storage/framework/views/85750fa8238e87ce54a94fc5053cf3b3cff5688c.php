<?php $__env->startSection('content'); ?>
        <div >
                <h1>HALAMAN DEPAN</h1>
        </div>

        <div class="list-group">
            <a href="/welcome" class="list-group-item list-group-item-action active">
                Halaman Depan
            </a>
            <a href="/home" class="list-group-item list-group-item-action">
                Home
            </a>
            <a href="/instal" class="list-group-item list-group-item-action">
                Instalasi Laravel
            </a>
            <a href="/about" class="list-group-item list-group-item-action">
                About Me
            </a>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Belajar Web 2 (Laravel)\UTS_WEB2_2020\resources\views/welcome.blade.php ENDPATH**/ ?>