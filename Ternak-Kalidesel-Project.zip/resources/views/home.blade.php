@extends('master')

@section('content')
        <div >
                <h1>UTS WEB 2 – Dhiaulhaq Aryaputra Falah Amurya</h1>
        </div>
@endsection
