@extends('master')

@section('content')

        <div >
                <h1>Instal Laravel</h1>
        </div>

        <div class="list-group">
            <a href="https://drive.google.com/file/d/1vqBkRowFd6p6KQ5kNBBIVsaam4Hd2EJA/view?usp=sharing" class="list-group-item list-group-item-action active">
                Langkah-langkah yang membuat project laravel.
            </a>
        </div>
@endsection
